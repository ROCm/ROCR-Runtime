// University of Illinois/NCSA
// Open Source License
//
// Copyright (c) 2013-2015, Advanced Micro Devices, Inc.
// All rights reserved.
//
// Developed by:
//
//     HSA Team
//
//     Advanced Micro Devices, Inc
//
//     www.amd.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal with
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
// of the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:
//
//     * Redistributions of source code must retain the above copyright notice,
//       this list of conditions and the following disclaimers.
//
//     * Redistributions in binary form must reproduce the above copyright notice,
//       this list of conditions and the following disclaimers in the
//       documentation and/or other materials provided with the distribution.
//
//     * Neither the names of the LLVM Team, University of Illinois at
//       Urbana-Champaign, nor the names of its contributors may be used to
//       endorse or promote products derived from this Software without specific
//       prior written permission.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
// FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH THE
// SOFTWARE.

const string enum2str( BrigAlignment arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_ALIGN, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigAllocation arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigAluModifierMask arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigAtomicOperation arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_SIGNALOPERATION, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigCompareOperation arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_COMPARE, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigControlDirective arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigImageChannelOrder arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigImageChannelType arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigImageGeometry arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_GEOMETRY, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigImageQuery arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_IMAGEQUERY, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigKind arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigLinkage arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigMachineModel arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigMemoryModifierMask arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigMemoryOrder arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_MEMORYORDER, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigMemoryScope arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_GROUPSEGMENTMEMORYSCOPE, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigOpcode arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_OPCODE, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigPack arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_PACK, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigProfile arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigRegisterKind arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigRound arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_ROUND, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSamplerAddressing arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSamplerCoordNormalization arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSamplerFilter arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSamplerQuery arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_SAMPLERQUERY, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSectionIndex arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSegCvtModifierMask arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigSegment arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_SEGMENT, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigType arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_SOURCETYPE, arg);
    if (res.empty()) return "?";
    return res;
}

const string enum2str( BrigWidth arg ) const
{
    string res = HSAIL_ASM::enum2str(arg);
    if (res.empty()) res = extEnum2str(HSAIL_PROPS::PROP_WIDTH, arg);
    if (res.empty()) return "?";
    return res;
}

