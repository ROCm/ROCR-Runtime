// University of Illinois/NCSA
// Open Source License
//
// Copyright (c) 2013-2015, Advanced Micro Devices, Inc.
// All rights reserved.
//
// Developed by:
//
//     HSA Team
//
//     Advanced Micro Devices, Inc
//
//     www.amd.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal with
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
// of the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:
//
//     * Redistributions of source code must retain the above copyright notice,
//       this list of conditions and the following disclaimers.
//
//     * Redistributions in binary form must reproduce the above copyright notice,
//       this list of conditions and the following disclaimers in the
//       documentation and/or other materials provided with the distribution.
//
//     * Neither the names of the LLVM Team, University of Illinois at
//       Urbana-Champaign, nor the names of its contributors may be used to
//       endorse or promote products derived from this Software without specific
//       prior written permission.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
// FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH THE
// SOFTWARE.
class AluModifier;
class Code;
class Directive;
class DirectiveArgBlockEnd;
class DirectiveArgBlockStart;
class DirectiveComment;
class DirectiveControl;
class DirectiveExecutable;
class DirectiveFunction;
class DirectiveIndirectFunction;
class DirectiveKernel;
class DirectiveSignature;
class DirectiveExtension;
class DirectiveFbarrier;
class DirectiveLabel;
class DirectiveLoc;
class DirectiveModule;
class DirectiveNone;
class DirectivePragma;
class DirectiveVariable;
class Inst;
class InstAddr;
class InstAtomic;
class InstBasic;
class InstBr;
class InstCmp;
class InstCvt;
class InstImage;
class InstLane;
class InstMem;
class InstMemFence;
class InstMod;
class InstQueryImage;
class InstQuerySampler;
class InstQueue;
class InstSeg;
class InstSegCvt;
class InstSignal;
class InstSourceType;
class ExecutableModifier;
class MemoryModifier;
class Operand;
class OperandAddress;
class OperandAlign;
class OperandCodeList;
class OperandCodeRef;
class OperandConstantBytes;
class OperandConstantImage;
class OperandConstantOperandList;
class OperandConstantSampler;
class OperandOperandList;
class OperandRegister;
class OperandString;
class OperandWavesize;
class SegCvtModifier;
class UInt64;
class VariableModifier;


class AluModifier : public ItemBase {
public:

	/// accessors
	ValRef<uint8_t>                                    allBits();
	BitValRef<0>                                       ftz();


	/// constructors
	AluModifier()                           : ItemBase() { }
	AluModifier(MySection* s, Offset o)     : ItemBase(s, o) { }
	AluModifier(const AluModifier& rhs) : ItemBase(rhs) { }
	AluModifier& operator=(const AluModifier& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigAluModifier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "AluModifier"; }
};

class Code : public ItemBase {
    // children: BrigDirective,BrigDirectiveArgBlockEnd,BrigDirectiveArgBlockStart,BrigDirectiveComment,BrigDirectiveControl,BrigDirectiveExecutable,BrigDirectiveExtension,BrigDirectiveFbarrier,BrigDirectiveFunction,BrigDirectiveIndirectFunction,BrigDirectiveKernel,BrigDirectiveLabel,BrigDirectiveLoc,BrigDirectiveModule,BrigDirectiveNone,BrigDirectivePragma,BrigDirectiveSignature,BrigDirectiveVariable,BrigInstAddr,BrigInstAtomic,BrigInstBase,BrigInstBasic,BrigInstBr,BrigInstCmp,BrigInstCvt,BrigInstImage,BrigInstLane,BrigInstMem,BrigInstMemFence,BrigInstMod,BrigInstQueryImage,BrigInstQuerySampler,BrigInstQueue,BrigInstSeg,BrigInstSegCvt,BrigInstSignal,BrigInstSourceType
public:

	typedef Code Kind;

	enum { SECTION = BRIG_SECTION_INDEX_CODE };

	/// accessors


	/// constructors
	Code()                           : ItemBase() { }
	Code(MySection* s, Offset o)     : ItemBase(s, o) { }
	Code(BrigContainer* c, Offset o) : ItemBase(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_END
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_START
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_COMMENT
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_CONTROL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_EXTENSION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_FBARRIER
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_INDIRECT_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_KERNEL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_LABEL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_LOC
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_MODULE
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_PRAGMA
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_SIGNATURE
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_VARIABLE
		    || rhs.kind() == BRIG_KIND_INST_ADDR
		    || rhs.kind() == BRIG_KIND_INST_ATOMIC
		    || rhs.kind() == BRIG_KIND_INST_BASIC
		    || rhs.kind() == BRIG_KIND_INST_BR
		    || rhs.kind() == BRIG_KIND_INST_CMP
		    || rhs.kind() == BRIG_KIND_INST_CVT
		    || rhs.kind() == BRIG_KIND_INST_IMAGE
		    || rhs.kind() == BRIG_KIND_INST_LANE
		    || rhs.kind() == BRIG_KIND_INST_MEM
		    || rhs.kind() == BRIG_KIND_INST_MEM_FENCE
		    || rhs.kind() == BRIG_KIND_INST_MOD
		    || rhs.kind() == BRIG_KIND_INST_QUERY_IMAGE
		    || rhs.kind() == BRIG_KIND_INST_QUERY_SAMPLER
		    || rhs.kind() == BRIG_KIND_INST_QUEUE
		    || rhs.kind() == BRIG_KIND_INST_SEG
		    || rhs.kind() == BRIG_KIND_INST_SEG_CVT
		    || rhs.kind() == BRIG_KIND_INST_SIGNAL
		    || rhs.kind() == BRIG_KIND_INST_SOURCE_TYPE
		    || rhs.kind() == BRIG_KIND_NONE;
	}
	Code(const ItemBase& rhs) { assignItem(*this,rhs); }
	Code& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigBase BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// root utilities
	Offset  brigSize() const { return brig()->byteCount; }
	Code next() const { return Code(section(), brigOffset() + brigSize()); }
};

class Directive : public Code {
    // children: BrigDirectiveArgBlockEnd,BrigDirectiveArgBlockStart,BrigDirectiveComment,BrigDirectiveControl,BrigDirectiveExecutable,BrigDirectiveExtension,BrigDirectiveFbarrier,BrigDirectiveFunction,BrigDirectiveIndirectFunction,BrigDirectiveKernel,BrigDirectiveLabel,BrigDirectiveLoc,BrigDirectiveModule,BrigDirectiveNone,BrigDirectivePragma,BrigDirectiveSignature,BrigDirectiveVariable
public:

	/// accessors


	/// constructors
	Directive()                           : Code() { }
	Directive(MySection* s, Offset o)     : Code(s, o) { }
	Directive(BrigContainer* c, Offset o) : Code(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_END
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_START
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_COMMENT
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_CONTROL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_EXTENSION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_FBARRIER
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_INDIRECT_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_KERNEL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_LABEL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_LOC
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_MODULE
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_PRAGMA
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_SIGNATURE
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_VARIABLE
		    || rhs.kind() == BRIG_KIND_NONE;
	}
	Directive(const ItemBase& rhs) { assignItem(*this,rhs); }
	Directive& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigBase BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();
};

class DirectiveArgBlockEnd : public Directive {
public:

	/// accessors


	/// constructors
	DirectiveArgBlockEnd()                           : Directive() { }
	DirectiveArgBlockEnd(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveArgBlockEnd(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_END;
	}
	DirectiveArgBlockEnd(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveArgBlockEnd& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveArgBlockEnd BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveArgBlockEnd"; }
};

class DirectiveArgBlockStart : public Directive {
public:

	/// accessors


	/// constructors
	DirectiveArgBlockStart()                           : Directive() { }
	DirectiveArgBlockStart(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveArgBlockStart(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_ARG_BLOCK_START;
	}
	DirectiveArgBlockStart(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveArgBlockStart& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveArgBlockStart BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveArgBlockStart"; }
};

class DirectiveComment : public Directive {
public:

	/// accessors
	StrRef                                             name();


	/// constructors
	DirectiveComment()                           : Directive() { }
	DirectiveComment(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveComment(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_COMMENT;
	}
	DirectiveComment(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveComment& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveComment BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveComment"; }
};

class DirectiveControl : public Directive {
public:

	/// accessors
	EnumValRef<BrigControlDirective,uint16_t>          control();
	ListRef<Operand>                                   operands();


	/// constructors
	DirectiveControl()                           : Directive() { }
	DirectiveControl(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveControl(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_CONTROL;
	}
	DirectiveControl(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveControl& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveControl BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveControl"; }
};

class DirectiveExecutable : public Directive {
    // children: BrigDirectiveFunction,BrigDirectiveIndirectFunction,BrigDirectiveKernel,BrigDirectiveSignature
public:

	/// accessors
	StrRef                                             name();
	ValRef<uint16_t>                                   outArgCount();
	ValRef<uint16_t>                                   inArgCount();
	ItemRef<Code>                                      firstInArg();
	ItemRef<Code>                                      firstCodeBlockEntry();
	ItemRef<Code>                                      nextModuleEntry();
	ExecutableModifier                                 modifier();
	EnumValRef<BrigLinkage,uint8_t>                    linkage();


	/// constructors
	DirectiveExecutable()                           : Directive() { }
	DirectiveExecutable(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveExecutable(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_INDIRECT_FUNCTION
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_KERNEL
		    || rhs.kind() == BRIG_KIND_DIRECTIVE_SIGNATURE;
	}
	DirectiveExecutable(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveExecutable& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExecutable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();
};

class DirectiveFunction : public DirectiveExecutable {
public:

	/// accessors


	/// constructors
	DirectiveFunction()                           : DirectiveExecutable() { }
	DirectiveFunction(MySection* s, Offset o)     : DirectiveExecutable(s, o) { }
	DirectiveFunction(BrigContainer* c, Offset o) : DirectiveExecutable(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_FUNCTION;
	}
	DirectiveFunction(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveFunction& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExecutable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveFunction"; }
};

class DirectiveIndirectFunction : public DirectiveExecutable {
public:

	/// accessors


	/// constructors
	DirectiveIndirectFunction()                           : DirectiveExecutable() { }
	DirectiveIndirectFunction(MySection* s, Offset o)     : DirectiveExecutable(s, o) { }
	DirectiveIndirectFunction(BrigContainer* c, Offset o) : DirectiveExecutable(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_INDIRECT_FUNCTION;
	}
	DirectiveIndirectFunction(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveIndirectFunction& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExecutable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveIndirectFunction"; }
};

class DirectiveKernel : public DirectiveExecutable {
public:

	/// accessors


	/// constructors
	DirectiveKernel()                           : DirectiveExecutable() { }
	DirectiveKernel(MySection* s, Offset o)     : DirectiveExecutable(s, o) { }
	DirectiveKernel(BrigContainer* c, Offset o) : DirectiveExecutable(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_KERNEL;
	}
	DirectiveKernel(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveKernel& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExecutable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveKernel"; }
};

class DirectiveSignature : public DirectiveExecutable {
public:

	/// accessors


	/// constructors
	DirectiveSignature()                           : DirectiveExecutable() { }
	DirectiveSignature(MySection* s, Offset o)     : DirectiveExecutable(s, o) { }
	DirectiveSignature(BrigContainer* c, Offset o) : DirectiveExecutable(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_SIGNATURE;
	}
	DirectiveSignature(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveSignature& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExecutable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveSignature"; }
};

class DirectiveExtension : public Directive {
public:

	/// accessors
	StrRef                                             name();


	/// constructors
	DirectiveExtension()                           : Directive() { }
	DirectiveExtension(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveExtension(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_EXTENSION;
	}
	DirectiveExtension(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveExtension& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveExtension BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveExtension"; }
};

class DirectiveFbarrier : public Directive {
public:

	/// accessors
	StrRef                                             name();
	VariableModifier                                   modifier();
	EnumValRef<BrigLinkage,uint8_t>                    linkage();


	/// constructors
	DirectiveFbarrier()                           : Directive() { }
	DirectiveFbarrier(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveFbarrier(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_FBARRIER;
	}
	DirectiveFbarrier(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveFbarrier& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveFbarrier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveFbarrier"; }
};

class DirectiveLabel : public Directive {
public:

	/// accessors
	StrRef                                             name();


	/// constructors
	DirectiveLabel()                           : Directive() { }
	DirectiveLabel(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveLabel(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_LABEL;
	}
	DirectiveLabel(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveLabel& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveLabel BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveLabel"; }
};

class DirectiveLoc : public Directive {
public:

	/// accessors
	StrRef                                             filename();
	ValRef<uint32_t>                                   line();
	ValRef<uint32_t>                                   column();


	/// constructors
	DirectiveLoc()                           : Directive() { }
	DirectiveLoc(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveLoc(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_LOC;
	}
	DirectiveLoc(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveLoc& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveLoc BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveLoc"; }
};

class DirectiveModule : public Directive {
public:

	/// accessors
	StrRef                                             name();
	ValRef<uint32_t>                                   hsailMajor();
	ValRef<uint32_t>                                   hsailMinor();
	EnumValRef<BrigProfile,uint8_t>                    profile();
	EnumValRef<BrigMachineModel,uint8_t>               machineModel();
	EnumValRef<BrigRound,uint8_t>                      defaultFloatRound();


	/// constructors
	DirectiveModule()                           : Directive() { }
	DirectiveModule(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveModule(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_MODULE;
	}
	DirectiveModule(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveModule& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveModule BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveModule"; }
};

class DirectiveNone : public Directive {
public:

	/// accessors


	/// constructors
	DirectiveNone()                           : Directive() { }
	DirectiveNone(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveNone(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_NONE;
	}
	DirectiveNone(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveNone& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveNone BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveNone"; }
};

class DirectivePragma : public Directive {
public:

	/// accessors
	ListRef<Operand>                                   operands();


	/// constructors
	DirectivePragma()                           : Directive() { }
	DirectivePragma(MySection* s, Offset o)     : Directive(s, o) { }
	DirectivePragma(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_PRAGMA;
	}
	DirectivePragma(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectivePragma& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectivePragma BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectivePragma"; }
};

class DirectiveVariable : public Directive {
public:

	/// accessors
	StrRef                                             name();
	ItemRef<Operand>                                   init();
	EnumValRef<BrigType,uint16_t>                      type();
	bool isArray();
	unsigned elementType();
	EnumValRef<BrigSegment,uint8_t>                    segment();
	EnumValRef<BrigAlignment,uint8_t>                  align();
	UInt64                                             dim();
	VariableModifier                                   modifier();
	EnumValRef<BrigLinkage,uint8_t>                    linkage();
	EnumValRef<BrigAllocation,uint8_t>                 allocation();


	/// constructors
	DirectiveVariable()                           : Directive() { }
	DirectiveVariable(MySection* s, Offset o)     : Directive(s, o) { }
	DirectiveVariable(BrigContainer* c, Offset o) : Directive(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_DIRECTIVE_VARIABLE;
	}
	DirectiveVariable(const ItemBase& rhs) { assignItem(*this,rhs); }
	DirectiveVariable& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigDirectiveVariable BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "DirectiveVariable"; }
};

class Inst : public Code {
    // children: BrigInstAddr,BrigInstAtomic,BrigInstBasic,BrigInstBr,BrigInstCmp,BrigInstCvt,BrigInstImage,BrigInstLane,BrigInstMem,BrigInstMemFence,BrigInstMod,BrigInstQueryImage,BrigInstQuerySampler,BrigInstQueue,BrigInstSeg,BrigInstSegCvt,BrigInstSignal,BrigInstSourceType
public:

	/// accessors
	EnumValRef<BrigOpcode,uint16_t>                    opcode();
	EnumValRef<BrigType,uint16_t>                      type();
	ListRef<Operand>                                   operands();
	Operand operand(int index);


	/// constructors
	Inst()                           : Code() { }
	Inst(MySection* s, Offset o)     : Code(s, o) { }
	Inst(BrigContainer* c, Offset o) : Code(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_ADDR
		    || rhs.kind() == BRIG_KIND_INST_ATOMIC
		    || rhs.kind() == BRIG_KIND_INST_BASIC
		    || rhs.kind() == BRIG_KIND_INST_BR
		    || rhs.kind() == BRIG_KIND_INST_CMP
		    || rhs.kind() == BRIG_KIND_INST_CVT
		    || rhs.kind() == BRIG_KIND_INST_IMAGE
		    || rhs.kind() == BRIG_KIND_INST_LANE
		    || rhs.kind() == BRIG_KIND_INST_MEM
		    || rhs.kind() == BRIG_KIND_INST_MEM_FENCE
		    || rhs.kind() == BRIG_KIND_INST_MOD
		    || rhs.kind() == BRIG_KIND_INST_QUERY_IMAGE
		    || rhs.kind() == BRIG_KIND_INST_QUERY_SAMPLER
		    || rhs.kind() == BRIG_KIND_INST_QUEUE
		    || rhs.kind() == BRIG_KIND_INST_SEG
		    || rhs.kind() == BRIG_KIND_INST_SEG_CVT
		    || rhs.kind() == BRIG_KIND_INST_SIGNAL
		    || rhs.kind() == BRIG_KIND_INST_SOURCE_TYPE;
	}
	Inst(const ItemBase& rhs) { assignItem(*this,rhs); }
	Inst& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstBase BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();
};

class InstAddr : public Inst {
public:

	/// accessors
	EnumValRef<BrigSegment,uint8_t>                    segment();


	/// constructors
	InstAddr()                           : Inst() { }
	InstAddr(MySection* s, Offset o)     : Inst(s, o) { }
	InstAddr(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_ADDR;
	}
	InstAddr(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstAddr& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstAddr BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstAddr"; }
};

class InstAtomic : public Inst {
public:

	/// accessors
	EnumValRef<BrigSegment,uint8_t>                    segment();
	EnumValRef<BrigMemoryOrder,uint8_t>                memoryOrder();
	EnumValRef<BrigMemoryScope,uint8_t>                memoryScope();
	EnumValRef<BrigAtomicOperation,uint8_t>            atomicOperation();
	ValRef<uint8_t>                                    equivClass();


	/// constructors
	InstAtomic()                           : Inst() { }
	InstAtomic(MySection* s, Offset o)     : Inst(s, o) { }
	InstAtomic(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_ATOMIC;
	}
	InstAtomic(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstAtomic& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstAtomic BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstAtomic"; }
};

class InstBasic : public Inst {
public:

	/// accessors


	/// constructors
	InstBasic()                           : Inst() { }
	InstBasic(MySection* s, Offset o)     : Inst(s, o) { }
	InstBasic(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_BASIC;
	}
	InstBasic(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstBasic& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstBasic BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstBasic"; }
};

class InstBr : public Inst {
public:

	/// accessors
	EnumValRef<BrigWidth,uint8_t>                      width();


	/// constructors
	InstBr()                           : Inst() { }
	InstBr(MySection* s, Offset o)     : Inst(s, o) { }
	InstBr(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_BR;
	}
	InstBr(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstBr& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstBr BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstBr"; }
};

class InstCmp : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      sourceType();
	AluModifier                                        modifier();
	EnumValRef<BrigCompareOperation,uint8_t>           compare();
	EnumValRef<BrigPack,uint8_t>                       pack();


	/// constructors
	InstCmp()                           : Inst() { }
	InstCmp(MySection* s, Offset o)     : Inst(s, o) { }
	InstCmp(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_CMP;
	}
	InstCmp(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstCmp& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstCmp BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstCmp"; }
};

class InstCvt : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      sourceType();
	AluModifier                                        modifier();
	EnumValRef<BrigRound,uint8_t>                      round();


	/// constructors
	InstCvt()                           : Inst() { }
	InstCvt(MySection* s, Offset o)     : Inst(s, o) { }
	InstCvt(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_CVT;
	}
	InstCvt(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstCvt& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstCvt BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstCvt"; }
};

class InstImage : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      imageType();
	EnumValRef<BrigType,uint16_t>                      coordType();
	EnumValRef<BrigImageGeometry,uint8_t>              geometry();
	ValRef<uint8_t>                                    equivClass();


	/// constructors
	InstImage()                           : Inst() { }
	InstImage(MySection* s, Offset o)     : Inst(s, o) { }
	InstImage(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_IMAGE;
	}
	InstImage(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstImage& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstImage BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstImage"; }
};

class InstLane : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      sourceType();
	EnumValRef<BrigWidth,uint8_t>                      width();


	/// constructors
	InstLane()                           : Inst() { }
	InstLane(MySection* s, Offset o)     : Inst(s, o) { }
	InstLane(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_LANE;
	}
	InstLane(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstLane& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstLane BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstLane"; }
};

class InstMem : public Inst {
public:

	/// accessors
	EnumValRef<BrigSegment,uint8_t>                    segment();
	EnumValRef<BrigAlignment,uint8_t>                  align();
	ValRef<uint8_t>                                    equivClass();
	EnumValRef<BrigWidth,uint8_t>                      width();
	MemoryModifier                                     modifier();


	/// constructors
	InstMem()                           : Inst() { }
	InstMem(MySection* s, Offset o)     : Inst(s, o) { }
	InstMem(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_MEM;
	}
	InstMem(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstMem& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstMem BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstMem"; }
};

class InstMemFence : public Inst {
public:

	/// accessors
	EnumValRef<BrigMemoryOrder,uint8_t>                memoryOrder();
	EnumValRef<BrigMemoryScope,uint8_t>                globalSegmentMemoryScope();
	EnumValRef<BrigMemoryScope,uint8_t>                groupSegmentMemoryScope();
	EnumValRef<BrigMemoryScope,uint8_t>                imageSegmentMemoryScope();


	/// constructors
	InstMemFence()                           : Inst() { }
	InstMemFence(MySection* s, Offset o)     : Inst(s, o) { }
	InstMemFence(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_MEM_FENCE;
	}
	InstMemFence(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstMemFence& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstMemFence BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstMemFence"; }
};

class InstMod : public Inst {
public:

	/// accessors
	AluModifier                                        modifier();
	EnumValRef<BrigRound,uint8_t>                      round();
	EnumValRef<BrigPack,uint8_t>                       pack();


	/// constructors
	InstMod()                           : Inst() { }
	InstMod(MySection* s, Offset o)     : Inst(s, o) { }
	InstMod(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_MOD;
	}
	InstMod(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstMod& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstMod BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstMod"; }
};

class InstQueryImage : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      imageType();
	EnumValRef<BrigImageGeometry,uint8_t>              geometry();
	EnumValRef<BrigImageQuery,uint8_t>                 imageQuery();


	/// constructors
	InstQueryImage()                           : Inst() { }
	InstQueryImage(MySection* s, Offset o)     : Inst(s, o) { }
	InstQueryImage(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_QUERY_IMAGE;
	}
	InstQueryImage(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstQueryImage& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstQueryImage BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstQueryImage"; }
};

class InstQuerySampler : public Inst {
public:

	/// accessors
	EnumValRef<BrigSamplerQuery,uint8_t>               samplerQuery();


	/// constructors
	InstQuerySampler()                           : Inst() { }
	InstQuerySampler(MySection* s, Offset o)     : Inst(s, o) { }
	InstQuerySampler(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_QUERY_SAMPLER;
	}
	InstQuerySampler(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstQuerySampler& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstQuerySampler BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstQuerySampler"; }
};

class InstQueue : public Inst {
public:

	/// accessors
	EnumValRef<BrigSegment,uint8_t>                    segment();
	EnumValRef<BrigMemoryOrder,uint8_t>                memoryOrder();


	/// constructors
	InstQueue()                           : Inst() { }
	InstQueue(MySection* s, Offset o)     : Inst(s, o) { }
	InstQueue(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_QUEUE;
	}
	InstQueue(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstQueue& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstQueue BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstQueue"; }
};

class InstSeg : public Inst {
public:

	/// accessors
	EnumValRef<BrigSegment,uint8_t>                    segment();


	/// constructors
	InstSeg()                           : Inst() { }
	InstSeg(MySection* s, Offset o)     : Inst(s, o) { }
	InstSeg(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_SEG;
	}
	InstSeg(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstSeg& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstSeg BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstSeg"; }
};

class InstSegCvt : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      sourceType();
	EnumValRef<BrigSegment,uint8_t>                    segment();
	SegCvtModifier                                     modifier();


	/// constructors
	InstSegCvt()                           : Inst() { }
	InstSegCvt(MySection* s, Offset o)     : Inst(s, o) { }
	InstSegCvt(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_SEG_CVT;
	}
	InstSegCvt(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstSegCvt& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstSegCvt BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstSegCvt"; }
};

class InstSignal : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      signalType();
	EnumValRef<BrigMemoryOrder,uint8_t>                memoryOrder();
	EnumValRef<BrigAtomicOperation,uint8_t>            signalOperation();


	/// constructors
	InstSignal()                           : Inst() { }
	InstSignal(MySection* s, Offset o)     : Inst(s, o) { }
	InstSignal(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_SIGNAL;
	}
	InstSignal(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstSignal& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstSignal BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstSignal"; }
};

class InstSourceType : public Inst {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      sourceType();


	/// constructors
	InstSourceType()                           : Inst() { }
	InstSourceType(MySection* s, Offset o)     : Inst(s, o) { }
	InstSourceType(BrigContainer* c, Offset o) : Inst(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_INST_SOURCE_TYPE;
	}
	InstSourceType(const ItemBase& rhs) { assignItem(*this,rhs); }
	InstSourceType& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigInstSourceType BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "InstSourceType"; }
};

class ExecutableModifier : public ItemBase {
public:

	/// accessors
	ValRef<uint8_t>                                    allBits();
	BitValRef<0>                                       isDefinition();


	/// constructors
	ExecutableModifier()                           : ItemBase() { }
	ExecutableModifier(MySection* s, Offset o)     : ItemBase(s, o) { }
	ExecutableModifier(const ExecutableModifier& rhs) : ItemBase(rhs) { }
	ExecutableModifier& operator=(const ExecutableModifier& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigExecutableModifier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "ExecutableModifier"; }
};

class MemoryModifier : public ItemBase {
public:

	/// accessors
	ValRef<uint8_t>                                    allBits();
	BitValRef<0>                                       isConst();


	/// constructors
	MemoryModifier()                           : ItemBase() { }
	MemoryModifier(MySection* s, Offset o)     : ItemBase(s, o) { }
	MemoryModifier(const MemoryModifier& rhs) : ItemBase(rhs) { }
	MemoryModifier& operator=(const MemoryModifier& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigMemoryModifier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "MemoryModifier"; }
};

class Operand : public ItemBase {
    // children: BrigOperandAddress,BrigOperandAlign,BrigOperandCodeList,BrigOperandCodeRef,BrigOperandConstantBytes,BrigOperandConstantImage,BrigOperandConstantOperandList,BrigOperandConstantSampler,BrigOperandOperandList,BrigOperandRegister,BrigOperandString,BrigOperandWavesize
public:

	typedef Operand Kind;

	enum { SECTION = BRIG_SECTION_INDEX_OPERAND };

	/// accessors


	/// constructors
	Operand()                           : ItemBase() { }
	Operand(MySection* s, Offset o)     : ItemBase(s, o) { }
	Operand(BrigContainer* c, Offset o) : ItemBase(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_ADDRESS
		    || rhs.kind() == BRIG_KIND_OPERAND_ALIGN
		    || rhs.kind() == BRIG_KIND_OPERAND_CODE_LIST
		    || rhs.kind() == BRIG_KIND_OPERAND_CODE_REF
		    || rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_BYTES
		    || rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_IMAGE
		    || rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_OPERAND_LIST
		    || rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_SAMPLER
		    || rhs.kind() == BRIG_KIND_OPERAND_OPERAND_LIST
		    || rhs.kind() == BRIG_KIND_OPERAND_REGISTER
		    || rhs.kind() == BRIG_KIND_OPERAND_STRING
		    || rhs.kind() == BRIG_KIND_OPERAND_WAVESIZE;
	}
	Operand(const ItemBase& rhs) { assignItem(*this,rhs); }
	Operand& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigBase BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// root utilities
	Offset  brigSize() const { return brig()->byteCount; }
	Operand next() const { return Operand(section(), brigOffset() + brigSize()); }
};

class OperandAddress : public Operand {
public:

	/// accessors
	ItemRef<DirectiveVariable>                         symbol();
	ItemRef<OperandRegister>                           reg();
	UInt64                                             offset();


	/// constructors
	OperandAddress()                           : Operand() { }
	OperandAddress(MySection* s, Offset o)     : Operand(s, o) { }
	OperandAddress(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_ADDRESS;
	}
	OperandAddress(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandAddress& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandAddress BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandAddress"; }
};

class OperandAlign : public Operand {
public:

	/// accessors
	EnumValRef<BrigAlignment,uint8_t>                  align();


	/// constructors
	OperandAlign()                           : Operand() { }
	OperandAlign(MySection* s, Offset o)     : Operand(s, o) { }
	OperandAlign(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_ALIGN;
	}
	OperandAlign(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandAlign& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandAlign BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandAlign"; }
};

class OperandCodeList : public Operand {
public:

	/// accessors
	ListRef<Code>                                      elements();
	unsigned elementCount();
	Code elements(int index);


	/// constructors
	OperandCodeList()                           : Operand() { }
	OperandCodeList(MySection* s, Offset o)     : Operand(s, o) { }
	OperandCodeList(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CODE_LIST;
	}
	OperandCodeList(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandCodeList& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandCodeList BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandCodeList"; }
};

class OperandCodeRef : public Operand {
public:

	/// accessors
	ItemRef<Code>                                      ref();


	/// constructors
	OperandCodeRef()                           : Operand() { }
	OperandCodeRef(MySection* s, Offset o)     : Operand(s, o) { }
	OperandCodeRef(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CODE_REF;
	}
	OperandCodeRef(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandCodeRef& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandCodeRef BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandCodeRef"; }
};

class OperandConstantBytes : public Operand {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      type();
	StrRef                                             bytes();


	/// constructors
	OperandConstantBytes()                           : Operand() { }
	OperandConstantBytes(MySection* s, Offset o)     : Operand(s, o) { }
	OperandConstantBytes(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_BYTES;
	}
	OperandConstantBytes(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandConstantBytes& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandConstantBytes BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandConstantBytes"; }
};

class OperandConstantImage : public Operand {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      type();
	EnumValRef<BrigImageGeometry,uint8_t>              geometry();
	EnumValRef<BrigImageChannelOrder,uint8_t>          channelOrder();
	EnumValRef<BrigImageChannelType,uint8_t>           channelType();
	UInt64                                             width();
	UInt64                                             height();
	UInt64                                             depth();
	UInt64                                             array();


	/// constructors
	OperandConstantImage()                           : Operand() { }
	OperandConstantImage(MySection* s, Offset o)     : Operand(s, o) { }
	OperandConstantImage(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_IMAGE;
	}
	OperandConstantImage(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandConstantImage& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandConstantImage BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandConstantImage"; }
};

class OperandConstantOperandList : public Operand {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      type();
	ListRef<Operand>                                   elements();
	unsigned elementCount();
	Operand elements(int index);


	/// constructors
	OperandConstantOperandList()                           : Operand() { }
	OperandConstantOperandList(MySection* s, Offset o)     : Operand(s, o) { }
	OperandConstantOperandList(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_OPERAND_LIST;
	}
	OperandConstantOperandList(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandConstantOperandList& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandConstantOperandList BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandConstantOperandList"; }
};

class OperandConstantSampler : public Operand {
public:

	/// accessors
	EnumValRef<BrigType,uint16_t>                      type();
	EnumValRef<BrigSamplerCoordNormalization,uint8_t>  coord();
	EnumValRef<BrigSamplerFilter,uint8_t>              filter();
	EnumValRef<BrigSamplerAddressing,uint8_t>          addressing();


	/// constructors
	OperandConstantSampler()                           : Operand() { }
	OperandConstantSampler(MySection* s, Offset o)     : Operand(s, o) { }
	OperandConstantSampler(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_CONSTANT_SAMPLER;
	}
	OperandConstantSampler(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandConstantSampler& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandConstantSampler BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandConstantSampler"; }
};

class OperandOperandList : public Operand {
public:

	/// accessors
	ListRef<Operand>                                   elements();
	unsigned elementCount();
	Operand elements(int index);


	/// constructors
	OperandOperandList()                           : Operand() { }
	OperandOperandList(MySection* s, Offset o)     : Operand(s, o) { }
	OperandOperandList(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_OPERAND_LIST;
	}
	OperandOperandList(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandOperandList& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandOperandList BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandOperandList"; }
};

class OperandRegister : public Operand {
public:

	/// accessors
	EnumValRef<BrigRegisterKind,uint16_t>              regKind();
	ValRef<uint16_t>                                   regNum();


	/// constructors
	OperandRegister()                           : Operand() { }
	OperandRegister(MySection* s, Offset o)     : Operand(s, o) { }
	OperandRegister(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_REGISTER;
	}
	OperandRegister(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandRegister& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandRegister BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandRegister"; }
};

class OperandString : public Operand {
public:

	/// accessors
	StrRef                                             string();


	/// constructors
	OperandString()                           : Operand() { }
	OperandString(MySection* s, Offset o)     : Operand(s, o) { }
	OperandString(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_STRING;
	}
	OperandString(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandString& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandString BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandString"; }
};

class OperandWavesize : public Operand {
public:

	/// accessors


	/// constructors
	OperandWavesize()                           : Operand() { }
	OperandWavesize(MySection* s, Offset o)     : Operand(s, o) { }
	OperandWavesize(BrigContainer* c, Offset o) : Operand(&c->sectionById(SECTION), o) { }

	/// assignment
	static bool isAssignable(const ItemBase& rhs) {
		return rhs.kind() == BRIG_KIND_OPERAND_WAVESIZE;
	}
	OperandWavesize(const ItemBase& rhs) { assignItem(*this,rhs); }
	OperandWavesize& operator=(const ItemBase& rhs) { assignItem(*this,rhs); return *this; }

	/// raw brig access
	typedef BrigOperandWavesize BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "OperandWavesize"; }
};

class SegCvtModifier : public ItemBase {
public:

	/// accessors
	ValRef<uint8_t>                                    allBits();
	BitValRef<0>                                       isNoNull();


	/// constructors
	SegCvtModifier()                           : ItemBase() { }
	SegCvtModifier(MySection* s, Offset o)     : ItemBase(s, o) { }
	SegCvtModifier(const SegCvtModifier& rhs) : ItemBase(rhs) { }
	SegCvtModifier& operator=(const SegCvtModifier& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigSegCvtModifier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "SegCvtModifier"; }
};

class UInt64 : public ItemBase {
public:

	/// accessors
	ValRef<uint32_t>                                   lo();
	ValRef<uint32_t>                                   hi();
	UInt64& operator=(uint64_t rhs);
	operator uint64_t();


	/// constructors
	UInt64()                           : ItemBase() { }
	UInt64(MySection* s, Offset o)     : ItemBase(s, o) { }
	UInt64(const UInt64& rhs) : ItemBase(rhs) { }
	UInt64& operator=(const UInt64& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigUInt64 BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "UInt64"; }
};

class VariableModifier : public ItemBase {
public:

	/// accessors
	ValRef<uint8_t>                                    allBits();
	BitValRef<0>                                       isDefinition();
	BitValRef<1>                                       isConst();


	/// constructors
	VariableModifier()                           : ItemBase() { }
	VariableModifier(MySection* s, Offset o)     : ItemBase(s, o) { }
	VariableModifier(const VariableModifier& rhs) : ItemBase(rhs) { }
	VariableModifier& operator=(const VariableModifier& rhs) { reset(rhs); return *this; }

	/// raw brig access
	typedef BrigVariableModifier BrigStruct;
	      BrigStruct* brig()       { return reinterpret_cast<BrigStruct*>      (m_section->getData(m_offset)); }
	const BrigStruct* brig() const { return reinterpret_cast<const BrigStruct*>(m_section->getData(m_offset)); }
	void initBrig();

	/// final utilities
	static const char *kindName() { return "VariableModifier"; }
};

